package com.example.demo.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Model.Login;
import com.example.demo.Model.Recharge;
import com.example.demo.Model.Register;
import com.example.demo.ResponseMsg.LoginMessage;

@Service
public interface RegisterService {
	public Register AddUser(Register register);
	public Register DisplayUserById(int id);
	public List<Register> DisplayAll();
	public LoginMessage LoginUser(Login login);
	
	public Recharge addRecharge(Recharge recharge);

	

}
