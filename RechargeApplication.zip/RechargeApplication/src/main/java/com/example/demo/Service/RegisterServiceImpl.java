package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.Model.Login;
import com.example.demo.Model.Recharge;
import com.example.demo.Model.Register;
import com.example.demo.Repository.RechargeRepo;
import
com.example.demo.Repository.RegisterRepository;
import com.example.demo.ResponseMsg.LoginMessage;

@Service
public class RegisterServiceImpl implements RegisterService {

	@Autowired 
	private RegisterRepository rr;
	
	@Autowired
	private RechargeRepo rp;

	@Override
	public Register AddUser(Register register)
	{ 
		return rr.save(register);
	}


	@Override 
	public List<Register> DisplayAll()
	{ 
		return rr.findAll();
	}


	@Override
	public Register DisplayUserById(int id) {
		return rr.findAllById(id);
}

	@Override
	public LoginMessage LoginUser(Login login) {
		System.out.println("Login user name"+login.getUname());
		Register r1=rr.findByUsername(login.getUname());
		if(r1!=null)
		{
			String unm=r1.getUname();
			String psd=r1.getPassword();

			/* Boolean ispwdRight=PasswordEncoder.matches(psd.encodePassword); */
			if(unm.equals(login.getUname()))
			{
				System.out.println(unm+": User Name + Password :"+psd);
				if(psd.equals(login.getPassword()))
				{
					System.out.println("Succesfully..............");
					return new LoginMessage("Login Successfully.......", true);
				}
				else {
					return new LoginMessage("Login Failed Password is Wrong.......", false);
				}
			}
			else
				return new LoginMessage("Login Failed UserName is Wrong.......", false);

		}
		return new LoginMessage("User Dosnt Exist.......", false);
	}


	@Override
	public Recharge addRecharge(Recharge recharge) {
		List<Register> r=DisplayAll();
		double updatedBal = 0;
		for(Register r1:r)
		{
	//		System.out.println(r1);
			if(recharge.getAcNO()==r1.getAccNo())
			{
				Double bal= r1.getBalance();
				if(bal<r1.getBalance())
					System.out.println(bal +""+recharge.getAmmount());
				updatedBal=bal-recharge.getAmmount();
				r1.setBalance(updatedBal);
				rr.save(r1);			
			}
			
		}
		return rp.save(recharge);
	}



	



}




