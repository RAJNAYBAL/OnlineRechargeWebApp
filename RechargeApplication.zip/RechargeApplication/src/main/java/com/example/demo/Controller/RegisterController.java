package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Login;
import com.example.demo.Model.Recharge;
import com.example.demo.Model.Register;
import com.example.demo.ResponseMsg.LoginMessage;
import com.example.demo.Service.RegisterService;

@RestController
public class RegisterController {
	
	
	@Autowired 
	private RegisterService rs;
	
	@PostMapping("/Register")
	public Register InsertUser(@RequestBody Register register)
	{
		return this.rs.AddUser(register);
	}
	
	@GetMapping("/Register/{accNO}")
	public Register DisplayById(@PathVariable int accNO )
	{
		return this.rs.DisplayUserById(accNO);
	}

	@GetMapping("/Register")
	public List<Register> displayAll()
	{
		return this.rs.DisplayAll();
	}
	
	@PostMapping("/login")
	public ResponseEntity<LoginMessage> LoginUser(@RequestBody Login login)
	{
		System.out.println(login+"   : This from Postman");
		LoginMessage logmsg=rs.LoginUser(login);
		return ResponseEntity.ok(logmsg);	
	}
	
	@PostMapping("/Recharge")
	public Recharge  addRechargeData(@RequestBody Recharge recharge)
	{
		return rs.addRecharge(recharge);
		
	}
	
}
