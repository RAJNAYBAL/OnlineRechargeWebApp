package com.example.demo.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Recharge {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String mob;
	private String sim;
	private float ammount;
	private int acNO;
	public Recharge(String mob, String sim, float ammount, int acNO) {
		super();
		this.mob = mob;
		this.sim = sim;
		this.ammount = ammount;
		this.acNO = acNO;
	}
	
	public Recharge() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	public float getAmmount() {
		return ammount;
	}
	public void setAmmount(float ammount) {
		this.ammount = ammount;
	}
	public int getAcNO() {
		return acNO;
	}
	public void setAcNO(int acNO) {
		this.acNO = acNO;
	}
	@Override
	public String toString() {
		return "Recharge [mob=" + mob + ", sim=" + sim + ", ammount=" + ammount + ", acNO=" + acNO + "]";
	}
	
}