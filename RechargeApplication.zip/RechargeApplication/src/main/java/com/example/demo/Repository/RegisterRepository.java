package com.example.demo.Repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Register;

@Repository
@EnableJpaRepositories
public interface RegisterRepository extends JpaRepository<Register,Integer>{

//	public Register findAllById(int id);
	
	@Query("select r from Register r where r.accNo =:n")
	Register findAllById(@Param("n") int accNo);
	
	@Query("select r from Register r where r.uname =:n")
	Register findByUsername(@Param("n") String unm);
	
	
	
	@Query("select r from Register r where r.uname =:n and r.password =:p")
	Register findByUserNameAndPass(@Param("n") String unm,@Param("p") String pass);

	

}
