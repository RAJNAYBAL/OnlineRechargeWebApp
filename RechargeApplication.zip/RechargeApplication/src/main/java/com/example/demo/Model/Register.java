package com.example.demo.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Table(name = "Register")
@Entity(name = "Register")
public class Register {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accNo;
	private String name;
	private String uname;
	private String password;
	private double balance;
	
	
	public Register(String name, String uname, String password, double balance) {
		super();
		this.name = name;
		this.uname = uname;
		this.password = password;
		this.balance = balance;
	}
	
	public Register(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}

	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Register [accNo=" + accNo + ", name=" + name + ", uname=" + uname + ", password=" + password
				+ ", balance=" + balance + "]";
	}
	
	
	
	

}
